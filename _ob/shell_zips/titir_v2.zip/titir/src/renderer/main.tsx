import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles/global.css";
import "./styles/shell.css";

const container = document.getElementById("root");
if (!container) throw new Error("Missing #root element");

createRoot(container).render(<App />);
