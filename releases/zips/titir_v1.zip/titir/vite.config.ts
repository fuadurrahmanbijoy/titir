import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Bundles the shell renderer ONLY (src/renderer/). Never touches
// main/preload (plain tsc, see tsconfig.json) or any plugin's own
// already-built JS/HTML/CSS (plugins/ is never compiled by TiTir).
export default defineConfig({
  root: "src/renderer",
  base: "./",
  plugins: [react()],
  build: {
    outDir: "../../dist/renderer",
    emptyOutDir: true,
  },
});
