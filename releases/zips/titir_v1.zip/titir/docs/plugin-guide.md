# TiTir — Plugin Guide

This is the plugin-author-facing counterpart to
`titir_technical_specification.md`. It restates the parts of that
document that matter when you're building *a* plugin, not the shell
itself — §6 (package format), §7 (install sequence), §11 (IPC
surface), §12 (security hardening), and §16 (boundaries a plugin must
never assume) — phrased as rules for someone who only sees the outside
of the system.

Every requirement below is tagged:

- **MANDATORY** — shell-enforced. Get this wrong and your install is
  refused, or your plugin simply won't run.
- **RECOMMENDED** — not enforced, but advisable. Skipping it won't
  block you, but it's asking for a worse experience or a future
  breakage.
- **FREE** — no shell opinion at all. Do whatever you want here.

---

## 1. Package Format

**MANDATORY.** A plugin is a single `.titirpkg` file — an ordinary zip
archive with this layout at its root:

```
my-plugin.titirpkg
├── manifest.json
├── index.html        (or whatever path manifest.entry points to)
├── preload.js         (or whatever path manifest.preload points to)
└── ...                any other assets your plugin needs
```

**MANDATORY manifest fields:**

| Field | Type | Notes |
|---|---|---|
| `id` | string | Lowercase, alphanumeric plus `.`/`-`. Must be unique among installed plugins. The `titir.*` namespace is reserved for built-in plugins — don't use it. |
| `name` | string | Shown in the nav-column tooltip and the Hub's plugin list. |
| `version` | string | Free-form; semver recommended, not enforced. |
| `entry` | string | Path, relative to the package root, to your HTML entry point. |
| `preload` | string | Path, relative to the package root, to your **already-compiled** preload script (`.js`). |

**FREE (optional) manifest fields:**

| Field | Type | Notes |
|---|---|---|
| `icon` | string | A single emoji or glyph. Defaults to a placeholder glyph if omitted. |
| `summary` | string | One-line description in the Hub's plugin list. |
| `permissions` | string[] | **Informational only in v1** — displayed, not enforced. Don't build correctness on it. |
| `minShellVersion` | string | Informational only — not checked against the running shell. |

**MANDATORY — no TypeScript/JSX at the manifest's `entry`/`preload`
paths.** Write your plugin in whatever language and toolchain you
like — TypeScript, JSX, any bundler — but compile everything down to
plain JS/HTML/CSS *before* zipping. TiTir never runs a compiler on
installed plugin code, ever, and the manifest can never point at a
`.ts`/`.tsx` file.

**FREE — everything else about your build.** Framework, bundler,
module system, whether your preload is CommonJS or a bundled IIFE:
entirely your call, so long as the file that lands at the declared
path works.

---

## 2. Install Sequence — What Happens When Someone Installs You

**MANDATORY**, in this order, and it's worth knowing so you can predict
refusals:

1. **Path-safety (zip-slip) check.** Every entry in your archive is
   checked, before a single byte is written, to confirm it would
   extract inside the plugin's own directory. An entry that tries to
   escape (e.g. `../../../etc/whatever`) gets the *entire* install
   rejected.
2. **Manifest validation** against the field table above.
3. **Invalid → refused**, with a specific error, and nothing left
   behind — no partial or half-registered plugin.
4. **Valid → path existence check** for `entry` and `preload`.
5. **Registration** — added to the registry with `enabled: true`.
6. **Broadcast** — your icon appears in the nav column immediately, no
   restart, no reload.

**MANDATORY — uninstall.** Reverse of the above: unmounted if running,
removed from the registry, files deleted from disk. You should not
assume any of your own persisted state on disk survives uninstall.

---

## 3. The IPC Surface Available to You

**MANDATORY — your capability surface is exactly this table, nothing
more, regardless of what your own code tries to do:**

| Channel | Who can call it | Payload → Response |
|---|---|---|
| `dialog:openFile` | Any plugin | `{ properties: string[]; filters?: {...}[] }` → `{ canceled: boolean; filePaths: string[] }` |

That's it. `dialog:openFile` is the one utility every plugin's preload
may call — it exists only because `dialog.showOpenDialog` runs in the
main process. Everything else about your renderer-to-preload contract
(your own custom IPC channels, if you add them) is entirely your own
business and invisible to TiTir.

**MANDATORY — the `titir:*` management channels (install, uninstall,
enable, reorder, snapshot) are wired only into the Hub's own preload,
by convention, not by a technical permission system in v1.** They
simply aren't exposed on your `window` object — your own preload never
receives them. Don't build a plugin whose correctness depends on
reaching them.

---

## 4. Security Hardening You Inherit (No Action Needed)

**MANDATORY, and none of it is something you configure — it's applied
to your view whether you like it or not:**

- `contextIsolation: true`, `sandbox: true`, `nodeIntegration: false`
  on every plugin view.
- Your preload runs sandboxed: it can `require('electron')` for a
  small set of Node built-ins, but has no filesystem, process, or
  native-module access. All privileged work happens through the IPC
  table above.
- Schema-validated IPC boundary — a malformed payload you send is
  rejected with a typed error, never reaches shell internals.

**RECOMMENDED — Content-Security-Policy on your own `index.html`.**
TiTir enforces a restrictive CSP (`default-src 'self'`, no remote
script execution) on its own shell renderer. For your plugin, this is
a strong recommendation, not a runtime-enforced restriction in v1 —
but building as if it *were* enforced will save you a rewrite later.

---

## 5. Boundaries You Must Never Assume

**MANDATORY — treat all of these as hard truths about the runtime:**

- You cannot resize, move, or reposition the window.
- You cannot change your own bounds within the content area — your
  internal layout is your own CSS/DOM problem.
- You get no pushed "visibility changed" event — a hidden plugin has
  no way to know it's hidden beyond the absence of user interaction.
- You cannot reach another plugin's `contextBridge` surface, or the
  shell renderer's.
- You cannot rely on `titir:*` channels being reachable (§3, above).
- You get no shell chrome inside your own view — no window controls,
  no plugin list, no idle state.
- You cannot get yourself pinned to the bottom of the nav column —
  that placement is exclusive to the built-in Hub.
- You cannot ship `.ts`/`.tsx` source directly inside your package.
- The zip-slip check protects the *host filesystem* during
  extraction — it does not protect your own package's internal file
  layout once extracted. That's your own responsibility.
- A declared `permissions` entry does nothing technically in v1 — it's
  displayed to the person using the app and nothing more.
- Your view is never mounted before its icon is first clicked — don't
  assume startup work runs before that.
- A mounted view is never destroyed except on crash or explicit
  uninstall — your background work (timers, in-flight requests) keeps
  running while hidden.
- No in-memory state is assumed to survive a crash. If you need state
  to survive, persist it to disk yourself, through your own preload's
  IPC calls.

---

## 6. Pre-Flight Checklist

Run through this before zipping, so most install refusals never reach
the shell's error-reporting path in the first place:

- [ ] `manifest.json` has `id`, `name`, `version`, `entry`, `preload` —
      all present, all the right types.
- [ ] `id` is lowercase, alphanumeric plus `.`/`-`, and does **not**
      start with `titir.`.
- [ ] `entry` and `preload` point at real files inside the package,
      and neither ends in `.ts`/`.tsx`.
- [ ] Every path inside your zip is relative and stays inside the
      package root — no `../` escapes.
- [ ] Your preload only calls `dialog:openFile` from the shared IPC
      surface, plus whatever bespoke channels you've wired up
      yourself.
- [ ] Nothing in your code assumes a `titir:*` management channel is
      reachable from your own `window` object.
- [ ] Nothing in your code assumes a `permissions` entry is enforced.

---

## 7. Troubleshooting

| Symptom at install/runtime | Cause | Where it's decided |
|---|---|---|
| "Install refused: Package entry ... would extract outside the plugin directory." | A zip entry's path resolves outside your plugin's own directory (zip-slip). | Technical Specification §7 step 1, §12 |
| "Install refused: manifest.json is missing or is not valid JSON." | No `manifest.json` at the archive root, or it isn't parseable JSON. | §7 step 2 |
| "Install refused: id ... uses the reserved 'titir.*' namespace ..." | Your `id` starts with `titir.`, which is reserved for built-in plugins. | §6 |
| "Install refused: entry/preload must point at compiled JS/HTML, not a .ts/.tsx source file." | Your manifest points at uncompiled TypeScript. | §6, §16 |
| "Install refused: a plugin with id ... is already installed." | Your `id` collides with an already-installed plugin. | §7 step 2 |
| "Install refused: entry/preload path ... does not exist in the package." | The file named in your manifest isn't actually in the zip. | §7 step 4 |
| Your plugin loads but a `titir:*` call silently does nothing / rejects | You're not the Hub — those channels aren't wired into your preload. | §11, §16 |
| Your preload throws on `require('fs')` or similar | Sandboxed preloads only get a small set of Node built-ins through `electron`, not full Node. | §4 |
