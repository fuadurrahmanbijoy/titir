import { BrowserWindow } from "electron";
import * as path from "path";
import type { PluginRegistry } from "../plugins/plugin-registry";
import { saveConfigDebounced } from "../store/config-store";

/**
 * Frameless BrowserWindow, custom-drawn chrome (Technical
 * Specification §3, §13). Window geometry is debounce-persisted to
 * titir.config.json on every resize/move, and restored on next boot
 * (§9, §13).
 */
export function createShellWindow(registry: PluginRegistry): BrowserWindow {
  const config = registry.getConfig();

  const win = new BrowserWindow({
    width: config.window.width,
    height: config.window.height,
    x: config.window.x ?? undefined,
    y: config.window.y ?? undefined,
    frame: false,
    webPreferences: {
      // Shell renderer's own preload — distinct from any plugin's.
      preload: path.join(__dirname, "../preload/shell-preload.js"),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
    },
  });

  // dist/main/window/ is two levels below dist/ — see the __dirname
  // rule in Technical Specification §5.
  win.loadFile(path.join(__dirname, "../../renderer/index.html"));

  const persistGeometry = () => {
    const bounds = win.getBounds();
    const cfg = registry.getConfig();
    cfg.window = { width: bounds.width, height: bounds.height, x: bounds.x, y: bounds.y };
    saveConfigDebounced(cfg);
  };

  win.on("resize", persistGeometry);
  win.on("move", persistGeometry);

  return win;
}
