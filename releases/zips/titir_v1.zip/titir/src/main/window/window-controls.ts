import { ipcMain, type BrowserWindow } from "electron";
import { emptyPayloadSchema } from "../ipc/schemas";

/**
 * ipcMain handlers for window:minimize/maximize/close (Technical
 * Specification §5, §11). Called from channels.ts, which owns the
 * single place every ipcMain.handle is wired up from — this module
 * just supplies the window-control handler logic itself.
 */
export function registerWindowControls(win: BrowserWindow): void {
  ipcMain.handle("window:minimize", (_event, payload) => {
    emptyPayloadSchema.safeParse(payload ?? {});
    win.minimize();
  });

  ipcMain.handle("window:maximize", (_event, payload) => {
    emptyPayloadSchema.safeParse(payload ?? {});
    if (win.isMaximized()) {
      win.unmaximize();
    } else {
      win.maximize();
    }
  });

  ipcMain.handle("window:close", (_event, payload) => {
    emptyPayloadSchema.safeParse(payload ?? {});
    win.close();
  });
}
