import { app } from "electron";
import * as path from "path";
import * as fs from "fs";
import { PluginRegistry } from "./plugins/plugin-registry";
import { PluginManager } from "./plugins/plugin-manager";
import { createShellWindow } from "./window/shell-window";
import { registerIpcChannels } from "./ipc/channels";
import { wireRegistryBroadcast, broadcastPluginCrashed } from "./ipc/broadcast";
import { validateManifest } from "./plugins/manifest-schema";
import { HUB_PLUGIN_ID, BUILTIN_PLUGINS_DIR, INSTALLED_PLUGINS_DIR } from "./shared/constants";

// dist/main/index.js -> __dirname = dist/main. The project root is one
// level up from there. plugins/ is never compiled by TiTir's own build
// (Technical Specification §5) — it's read from the source tree
// directly at runtime.
const projectRoot = path.join(__dirname, "..", "..");
const pluginsRoot = path.join(projectRoot, "plugins");
const installedRoot = path.join(pluginsRoot, INSTALLED_PLUGINS_DIR);
const hubDir = path.join(pluginsRoot, BUILTIN_PLUGINS_DIR, "hub");

fs.mkdirSync(installedRoot, { recursive: true });

function loadHubManifest(): { manifest: ReturnType<typeof validateManifest>["manifest"]; dir: string } {
  const manifestPath = path.join(hubDir, "manifest.json");
  const raw = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
  const result = validateManifest(raw, { allowReservedNamespace: true });
  if (!result.ok || !result.manifest) {
    throw new Error(`Built-in Hub manifest is invalid: ${result.errors.join("; ")}`);
  }
  if (result.manifest.id !== HUB_PLUGIN_ID) {
    throw new Error(`Built-in Hub manifest id must be "${HUB_PLUGIN_ID}".`);
  }
  return { manifest: result.manifest, dir: hubDir };
}

app.whenReady().then(() => {
  const registry = new PluginRegistry();

  // The Hub is unconditionally registered and mounted from
  // plugins/builtin/hub/ on every boot, independent of anything in
  // the config file (Technical Specification §9). It is not an entry
  // in ShellConfig.plugins[].
  const { manifest: hubManifest, dir: hubPath } = loadHubManifest();
  registry.registerHub(hubManifest!, hubPath);

  // Every other installed plugin is rehydrated by re-reading its
  // manifest.json fresh from disk (Technical Specification §9).
  registry.rehydrateInstalled(installedRoot);

  const win = createShellWindow(registry);

  const manager = new PluginManager(win, pluginsRoot, registry, (pluginId) => {
    broadcastPluginCrashed(win, pluginId);
  });

  registerIpcChannels(win, manager);
  wireRegistryBroadcast(win, manager.registry);

  win.on("resize", () => manager.onWindowResize());

  // A plugin is never mounted before its icon is first clicked
  // (Technical Specification §8) — the Hub is no exception; it stays
  // `registered` until the person clicks its nav-column slot.

  app.on("activate", () => {
    // Single-window application in v1 (Technical Specification §2) —
    // nothing to do here beyond Electron's default macOS convention of
    // not quitting on window-all-closed below.
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
