import { app } from "electron";
import * as fs from "fs";
import * as path from "path";
import { CONFIG_FILE_NAME } from "../shared/constants";
import type { ShellConfig } from "../shared/types";

// <userData>/titir.config.json is the only thing that survives a
// restart (Technical Specification §9). It rehydrates plugin-registry
// on boot; manifests themselves are always re-read fresh from disk.

const DEFAULT_CONFIG: ShellConfig = {
  window: { width: 1200, height: 800, x: null, y: null },
  activePluginId: null,
  plugins: [],
};

function configPath(): string {
  return path.join(app.getPath("userData"), CONFIG_FILE_NAME);
}

export function loadConfig(): ShellConfig {
  try {
    const raw = fs.readFileSync(configPath(), "utf-8");
    const parsed = JSON.parse(raw);
    // Shallow-merge over defaults so a partially-written or
    // older-shape config file never crashes boot.
    return {
      window: { ...DEFAULT_CONFIG.window, ...(parsed.window ?? {}) },
      activePluginId: parsed.activePluginId ?? null,
      plugins: Array.isArray(parsed.plugins) ? parsed.plugins : [],
    };
  } catch {
    return { ...DEFAULT_CONFIG };
  }
}

let writeTimer: NodeJS.Timeout | null = null;
let pendingConfig: ShellConfig | null = null;

function flush(): void {
  if (!pendingConfig) return;
  const target = configPath();
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, JSON.stringify(pendingConfig, null, 2), "utf-8");
  pendingConfig = null;
}

/** Immediate, synchronous write. Used for state changes that must not
 * be lost (install/uninstall/enable/reorder). */
export function saveConfig(config: ShellConfig): void {
  pendingConfig = config;
  flush();
}

/** Debounced write, used for high-frequency updates (window resize/move
 * — Technical Specification §13). */
export function saveConfigDebounced(config: ShellConfig, delayMs = 250): void {
  pendingConfig = config;
  if (writeTimer) clearTimeout(writeTimer);
  writeTimer = setTimeout(flush, delayMs);
}
