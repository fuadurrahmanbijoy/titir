import { contextBridge, ipcRenderer } from "electron";
import type {
  InstallPluginRequest,
  InstallPluginResponse,
  UninstallPluginRequest,
  UninstallPluginResponse,
  SetPluginEnabledRequest,
  SetPluginEnabledResponse,
  ReorderPluginsRequest,
  ReorderPluginsResponse,
  RegistrySnapshot,
  OpenFileRequest,
  OpenFileResponse,
  PluginCrashedEvent,
  PluginsChangedEvent,
  ShowPluginRequest,
  RelaunchPluginRequest,
} from "../shared/types";

// The shell renderer's own preload — distinct from any plugin's
// preload (Technical Specification §5). This is where the
// management (`titir:*`) channels are actually reachable from page
// JS, "by convention" per §11/§16 — nothing about this file's
// existence is special-cased on the main-process side; it's simply
// the only preload the shell chooses to load these into.

const titirApi = {
  installPlugin: (req: InstallPluginRequest): Promise<InstallPluginResponse> =>
    ipcRenderer.invoke("titir:installPlugin", req),
  uninstallPlugin: (req: UninstallPluginRequest): Promise<UninstallPluginResponse> =>
    ipcRenderer.invoke("titir:uninstallPlugin", req),
  setPluginEnabled: (req: SetPluginEnabledRequest): Promise<SetPluginEnabledResponse> =>
    ipcRenderer.invoke("titir:setPluginEnabled", req),
  reorderPlugins: (req: ReorderPluginsRequest): Promise<ReorderPluginsResponse> =>
    ipcRenderer.invoke("titir:reorderPlugins", req),
  getSnapshot: (): Promise<RegistrySnapshot> =>
    ipcRenderer.invoke("titir:getSnapshot", {}),
  showPlugin: (req: ShowPluginRequest): Promise<void> =>
    ipcRenderer.invoke("titir:showPlugin", req),
  relaunchPlugin: (req: RelaunchPluginRequest): Promise<void> =>
    ipcRenderer.invoke("titir:relaunchPlugin", req),
  onPluginsChanged: (listener: (event: PluginsChangedEvent) => void): (() => void) => {
    const handler = (_event: unknown, payload: PluginsChangedEvent) => listener(payload);
    ipcRenderer.on("titir:pluginsChanged", handler);
    return () => ipcRenderer.removeListener("titir:pluginsChanged", handler);
  },
  onPluginCrashed: (listener: (event: PluginCrashedEvent) => void): (() => void) => {
    const handler = (_event: unknown, payload: PluginCrashedEvent) => listener(payload);
    ipcRenderer.on("titir:pluginCrashed", handler);
    return () => ipcRenderer.removeListener("titir:pluginCrashed", handler);
  },
};

const dialogApi = {
  openFile: (req: OpenFileRequest): Promise<OpenFileResponse> =>
    ipcRenderer.invoke("dialog:openFile", req),
};

const windowApi = {
  minimize: (): Promise<void> => ipcRenderer.invoke("window:minimize", {}),
  maximize: (): Promise<void> => ipcRenderer.invoke("window:maximize", {}),
  close: (): Promise<void> => ipcRenderer.invoke("window:close", {}),
};

contextBridge.exposeInMainWorld("titir", titirApi);
contextBridge.exposeInMainWorld("dialogApi", dialogApi);
contextBridge.exposeInMainWorld("windowApi", windowApi);

export type ShellTitirApi = typeof titirApi;
export type ShellDialogApi = typeof dialogApi;
export type ShellWindowApi = typeof windowApi;
