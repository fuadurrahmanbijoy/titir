import { z } from "zod";

// Every ipcMain.handle parses its incoming payload against the
// matching schema here before touching it (Technical Specification
// §11, §12). A malformed/unexpected payload is rejected with a typed
// error and never reaches filesystem or process-level code.

export const installPluginSchema = z.object({
  packagePath: z.string().min(1),
});

export const uninstallPluginSchema = z.object({
  pluginId: z.string().min(1),
});

export const setPluginEnabledSchema = z.object({
  pluginId: z.string().min(1),
  enabled: z.boolean(),
});

export const reorderPluginsSchema = z.object({
  orderedIds: z.array(z.string().min(1)),
});

export const getSnapshotSchema = z.object({}).strict();

export const openFileSchema = z.object({
  properties: z.array(z.string()),
  filters: z
    .array(z.object({ name: z.string(), extensions: z.array(z.string()) }))
    .optional(),
});

export const emptyPayloadSchema = z.object({}).strict();

// Shell-only additions (see the note beside ShowPluginRequest in
// shared/types.ts) — drive the mount/show and relaunch transitions
// from the shell renderer's nav-icon clicks and crash-toast button.
export const showPluginSchema = z.object({
  pluginId: z.string().min(1),
});

export const relaunchPluginSchema = z.object({
  pluginId: z.string().min(1),
});
