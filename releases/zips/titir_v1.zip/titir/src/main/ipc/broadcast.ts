import type { BrowserWindow } from "electron";
import type { PluginRegistry } from "../plugins/plugin-registry";
import type { PluginsChangedReason, RegistrySnapshot } from "../shared/types";

/**
 * Wires the registry's "changed" event to titir:pluginsChanged pushed
 * into the shell renderer (Technical Specification §9, §11). Every
 * transition — install, uninstall, enable/disable, reorder — fires the
 * instant it happens in the main process. Renderer subscribers never
 * poll or re-fetch on a timer (Technical Specification §8).
 */
export function wireRegistryBroadcast(win: BrowserWindow, registry: PluginRegistry): void {
  registry.on("changed", (reason: PluginsChangedReason, snapshot: RegistrySnapshot) => {
    win.webContents.send("titir:pluginsChanged", { reason, snapshot });
  });
}

export function broadcastPluginCrashed(win: BrowserWindow, pluginId: string): void {
  win.webContents.send("titir:pluginCrashed", { pluginId });
}
