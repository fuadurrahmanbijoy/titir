import { ipcMain, dialog, type BrowserWindow } from "electron";
import type { PluginManager } from "../plugins/plugin-manager";
import { registerWindowControls } from "../window/window-controls";
import {
  installPluginSchema,
  uninstallPluginSchema,
  setPluginEnabledSchema,
  reorderPluginsSchema,
  getSnapshotSchema,
  openFileSchema,
  showPluginSchema,
  relaunchPluginSchema,
} from "./schemas";

/**
 * Registers every ipcMain.handle named in Technical Specification §11.
 *
 * `titir:*` management channels are wired only into the Hub plugin's
 * preload, by convention — not by a technical permission system in v1
 * (§11, §16). The handlers here do not check the sender's identity;
 * that is exactly what "by convention, not enforced" means in this
 * revision. A third-party plugin whose own preload never received
 * these functions from its contextBridge simply has no way to reach
 * them through its page JS, but nothing here technically prevents a
 * plugin author from wiring the raw ipcRenderer call into their own
 * preload if they chose to. That gap is explicitly out of scope for
 * v1 (§2).
 *
 * Every payload is parsed against its zod schema before any handler
 * logic runs (§12) — a malformed payload is rejected, never reaches
 * filesystem or process-level code.
 */
export function registerIpcChannels(win: BrowserWindow, manager: PluginManager): void {
  ipcMain.handle("titir:installPlugin", async (_event, payload) => {
    const parsed = installPluginSchema.safeParse(payload);
    if (!parsed.success) {
      return { ok: false, error: "Invalid installPlugin payload." };
    }
    return manager.install(parsed.data);
  });

  ipcMain.handle("titir:uninstallPlugin", (_event, payload) => {
    const parsed = uninstallPluginSchema.safeParse(payload);
    if (!parsed.success) {
      return { ok: false, error: "Invalid uninstallPlugin payload." };
    }
    return manager.uninstall(parsed.data);
  });

  ipcMain.handle("titir:setPluginEnabled", (_event, payload) => {
    const parsed = setPluginEnabledSchema.safeParse(payload);
    if (!parsed.success) {
      return { ok: false };
    }
    return manager.setEnabled(parsed.data);
  });

  ipcMain.handle("titir:reorderPlugins", (_event, payload) => {
    const parsed = reorderPluginsSchema.safeParse(payload);
    if (!parsed.success) {
      return { ok: false };
    }
    return manager.reorder(parsed.data);
  });

  ipcMain.handle("titir:getSnapshot", (_event, payload) => {
    const parsed = getSnapshotSchema.safeParse(payload ?? {});
    if (!parsed.success) {
      return manager.getSnapshot();
    }
    return manager.getSnapshot();
  });

  ipcMain.handle("dialog:openFile", async (_event, payload) => {
    const parsed = openFileSchema.safeParse(payload);
    if (!parsed.success) {
      return { canceled: true, filePaths: [] };
    }
    const result = await dialog.showOpenDialog(win, {
      properties: parsed.data.properties as Electron.OpenDialogOptions["properties"],
      filters: parsed.data.filters,
    });
    return { canceled: result.canceled, filePaths: result.filePaths };
  });

  registerWindowControls(win);

  // Shell-only: driven by nav-icon clicks (PluginList.tsx / HubEntry.tsx)
  // and the crash toast's Relaunch button (App.tsx) — see the note in
  // shared/types.ts.
  ipcMain.handle("titir:showPlugin", (_event, payload) => {
    const parsed = showPluginSchema.safeParse(payload);
    if (!parsed.success) return;
    manager.showPlugin(parsed.data.pluginId);
  });

  ipcMain.handle("titir:relaunchPlugin", (_event, payload) => {
    const parsed = relaunchPluginSchema.safeParse(payload);
    if (!parsed.success) return;
    manager.relaunchPlugin(parsed.data.pluginId);
  });
}
