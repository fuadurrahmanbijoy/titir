import type { BrowserWindow } from "electron";
import * as path from "path";
import { PluginRegistry } from "./plugin-registry";
import { PluginLifecycle } from "./lifecycle";
import { installPlugin, uninstallPlugin } from "./plugin-installer";
import { HUB_PLUGIN_ID, INSTALLED_PLUGINS_DIR } from "../shared/constants";
import type {
  InstallPluginRequest,
  InstallPluginResponse,
  UninstallPluginRequest,
  UninstallPluginResponse,
  SetPluginEnabledRequest,
  SetPluginEnabledResponse,
  ReorderPluginsRequest,
  ReorderPluginsResponse,
  RegistrySnapshot,
} from "../shared/types";

/**
 * Facade — every plugin-related IPC call is routed through this
 * (Technical Specification §5). Wraps the registry + lifecycle so
 * channels.ts stays a thin dispatch layer with no business logic of
 * its own.
 */
export class PluginManager {
  readonly registry: PluginRegistry;
  readonly lifecycle: PluginLifecycle;
  private readonly installedRoot: string;

  constructor(
    win: BrowserWindow,
    pluginsRoot: string,
    registry: PluginRegistry,
    onCrashed: (pluginId: string) => void
  ) {
    this.registry = registry;
    this.installedRoot = path.join(pluginsRoot, INSTALLED_PLUGINS_DIR);
    this.lifecycle = new PluginLifecycle(win, this.registry, onCrashed);
  }

  getInstalledRoot(): string {
    return this.installedRoot;
  }

  async install(req: InstallPluginRequest): Promise<InstallPluginResponse> {
    return installPlugin(req.packagePath, this.installedRoot, this.registry);
  }

  uninstall(req: UninstallPluginRequest): UninstallPluginResponse {
    if (req.pluginId === HUB_PLUGIN_ID) {
      return { ok: false, error: "The Hub cannot be uninstalled." };
    }
    this.lifecycle.unmount(req.pluginId);
    return uninstallPlugin(req.pluginId, this.installedRoot, this.registry);
  }

  setEnabled(req: SetPluginEnabledRequest): SetPluginEnabledResponse {
    if (!req.enabled) {
      // A disabled plugin is absent from the nav column entirely
      // (Visual Guide §A4) — unmount it so it stops running too.
      this.lifecycle.unmount(req.pluginId);
    }
    return { ok: this.registry.setEnabled(req.pluginId, req.enabled) };
  }

  reorder(req: ReorderPluginsRequest): ReorderPluginsResponse {
    return { ok: this.registry.reorder(req.orderedIds) };
  }

  getSnapshot(): RegistrySnapshot {
    return this.registry.snapshot();
  }

  showPlugin(pluginId: string): void {
    if (!this.registry.has(pluginId)) return;
    const entry = this.registry.get(pluginId);
    if (entry && !entry.isHub && !entry.enabled) return;
    this.lifecycle.show(pluginId);
  }

  relaunchPlugin(pluginId: string): void {
    this.lifecycle.relaunch(pluginId);
  }

  onWindowResize(): void {
    this.lifecycle.onWindowResize();
  }
}
