import * as fs from "fs";
import * as path from "path";
import * as yauzl from "yauzl";
import { validateManifest } from "./manifest-schema";
import type { PluginRegistry } from "./plugin-registry";
import type { InstallPluginResponse } from "../shared/types";

/**
 * Install-time sequence, in this exact order (Technical Specification
 * §7, security rationale in §12):
 *   1. Extraction with path-safety (zip-slip) checking — runs before
 *      a single byte is written and before the manifest is even read.
 *   2. Manifest validation.
 *   3. Invalid -> refused, extracted files deleted, no partial install
 *      left behind.
 *   4. Valid -> entry/preload path existence check.
 *   5. Registration.
 *   6. Broadcast (handled by the registry's "changed" event).
 */
export async function installPlugin(
  packagePath: string,
  installedRoot: string,
  registry: PluginRegistry
): Promise<InstallPluginResponse> {
  // We don't know the final plugin id until the manifest is read, but
  // the zip-slip check must run before we trust anything in the
  // archive — including the id. So we extract into a temporary staging
  // directory first, and only move it to plugins/installed/<id>/ once
  // the manifest is known and valid. The path-safety check itself is
  // still performed relative to what the *final* per-plugin directory
  // would be, per entry, before any byte of that entry is written.
  const stagingDir = path.join(installedRoot, `.staging-${Date.now()}-${Math.random().toString(36).slice(2)}`);

  try {
    await extractWithPathSafety(packagePath, stagingDir);
  } catch (err) {
    cleanupDir(stagingDir);
    return { ok: false, error: `Install refused: ${(err as Error).message}` };
  }

  let raw: unknown;
  try {
    const manifestPath = path.join(stagingDir, "manifest.json");
    raw = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
  } catch {
    cleanupDir(stagingDir);
    return { ok: false, error: "Install refused: manifest.json is missing or is not valid JSON." };
  }

  const result = validateManifest(raw);
  if (!result.ok || !result.manifest) {
    cleanupDir(stagingDir);
    return { ok: false, error: `Install refused: ${result.errors.join("; ")}` };
  }
  const manifest = result.manifest;

  if (registry.has(manifest.id)) {
    cleanupDir(stagingDir);
    return { ok: false, error: `Install refused: a plugin with id "${manifest.id}" is already installed.` };
  }

  const entryPath = path.join(stagingDir, manifest.entry);
  const preloadPath = path.join(stagingDir, manifest.preload);
  if (!fs.existsSync(entryPath)) {
    cleanupDir(stagingDir);
    return { ok: false, error: `Install refused: entry path "${manifest.entry}" does not exist in the package.` };
  }
  if (!fs.existsSync(preloadPath)) {
    cleanupDir(stagingDir);
    return { ok: false, error: `Install refused: preload path "${manifest.preload}" does not exist in the package.` };
  }

  const finalDir = path.join(installedRoot, manifest.id);
  fs.renameSync(stagingDir, finalDir);

  registry.register(manifest, finalDir);

  return { ok: true, pluginId: manifest.id };
}

export function uninstallPlugin(pluginId: string, installedRoot: string, registry: PluginRegistry): { ok: boolean; error?: string } {
  const entry = registry.get(pluginId);
  if (!entry || entry.isHub) {
    return { ok: false, error: `No uninstallable plugin with id "${pluginId}".` };
  }
  registry.unregister(pluginId);
  const dir = path.join(installedRoot, pluginId);
  cleanupDir(dir);
  return { ok: true };
}

function cleanupDir(dir: string): void {
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch {
    // best-effort; nothing further we can do if the OS won't remove it
  }
}

/**
 * Extracts a zip archive entry-by-entry (yauzl was chosen specifically
 * because it exposes entries one at a time — Technical Specification
 * §3), rejecting the ENTIRE install if any single entry would resolve
 * outside the target directory (a classic zip-slip attack). This is a
 * security control, not merely an install-flow detail (§12) — it runs
 * before any byte is written and before the manifest is trusted enough
 * to even be parsed as JSON.
 */
function extractWithPathSafety(zipPath: string, targetDir: string): Promise<void> {
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
      if (err || !zipfile) {
        reject(err ?? new Error("Could not open package as a zip archive."));
        return;
      }

      fs.mkdirSync(targetDir, { recursive: true });
      const resolvedTarget = path.resolve(targetDir);

      zipfile.readEntry();

      zipfile.on("entry", (entry: yauzl.Entry) => {
        const entryPath = path.resolve(targetDir, entry.fileName);

        // The zip-slip check itself: the resolved absolute path must
        // stay within resolvedTarget.
        if (
          entryPath !== resolvedTarget &&
          !entryPath.startsWith(resolvedTarget + path.sep)
        ) {
          zipfile.close();
          reject(new Error(`Package entry "${entry.fileName}" would extract outside the plugin directory.`));
          return;
        }

        if (/\/$/.test(entry.fileName)) {
          // Directory entry.
          fs.mkdirSync(entryPath, { recursive: true });
          zipfile.readEntry();
          return;
        }

        fs.mkdirSync(path.dirname(entryPath), { recursive: true });
        zipfile.openReadStream(entry, (streamErr, readStream) => {
          if (streamErr || !readStream) {
            zipfile.close();
            reject(streamErr ?? new Error(`Could not read entry "${entry.fileName}".`));
            return;
          }
          const writeStream = fs.createWriteStream(entryPath);
          readStream.pipe(writeStream);
          writeStream.on("finish", () => zipfile.readEntry());
          writeStream.on("error", (writeErr) => {
            zipfile.close();
            reject(writeErr);
          });
        });
      });

      zipfile.on("end", () => resolve());
      zipfile.on("error", (zipErr) => reject(zipErr));
    });
  });
}
