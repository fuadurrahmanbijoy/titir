import { EventEmitter } from "events";
import * as fs from "fs";
import * as path from "path";
import { HUB_PLUGIN_ID } from "../shared/constants";
import { loadConfig, saveConfig } from "../store/config-store";
import { validateManifest } from "./manifest-schema";
import type {
  PluginManifest,
  PluginRuntimeState,
  PluginSnapshotEntry,
  PluginsChangedReason,
  RegistrySnapshot,
  ShellConfig,
} from "../shared/types";

interface RegistryEntry {
  manifest: PluginManifest;
  dir: string; // absolute directory the manifest/entry/preload live under
  enabled: boolean;
  order: number;
  state: PluginRuntimeState;
  isHub: boolean;
}

/**
 * In-memory registry of every known plugin, plus the persisted
 * enabled/order state (Technical Specification §9). The Hub is
 * registered here like any other plugin for lookup purposes, but is
 * never written into ShellConfig.plugins[] (§9's explicit decision) —
 * it has no enabled/order to persist because neither is ever
 * changeable for it.
 *
 * Emits "changed" with a PluginsChangedReason; ipc/broadcast.ts
 * forwards that to the shell renderer as titir:pluginsChanged. This is
 * the single source of the "push-based, never poll-based" guarantee
 * in Technical Specification §8.
 */
export class PluginRegistry extends EventEmitter {
  private entries = new Map<string, RegistryEntry>();
  private config: ShellConfig;

  constructor() {
    super();
    this.config = loadConfig();
  }

  /** Registers the built-in Hub, unconditionally, every boot. */
  registerHub(manifest: PluginManifest, dir: string): void {
    this.entries.set(manifest.id, {
      manifest,
      dir,
      enabled: true,
      order: -1, // pinned outside the ordinary list, order is meaningless
      state: "registered",
      isHub: true,
    });
  }

  /** Rehydrates already-installed third-party plugins from
   * plugins/installed/, re-reading each manifest.json fresh from disk
   * and cross-referencing persisted enabled/order state. */
  rehydrateInstalled(installedRoot: string): void {
    let ids: string[];
    try {
      ids = fs.readdirSync(installedRoot, { withFileTypes: true })
        .filter((d) => d.isDirectory())
        .map((d) => d.name);
    } catch {
      return;
    }

    for (const id of ids) {
      const dir = path.join(installedRoot, id);
      const manifestPath = path.join(dir, "manifest.json");
      let raw: unknown;
      try {
        raw = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
      } catch {
        continue; // corrupted/missing manifest on disk — skip silently
      }
      const result = validateManifest(raw);
      if (!result.ok || !result.manifest) continue;

      const persisted = this.config.plugins.find((p) => p.id === result.manifest!.id);
      this.entries.set(result.manifest.id, {
        manifest: result.manifest,
        dir,
        enabled: persisted?.enabled ?? true,
        order: persisted?.order ?? this.nextOrder(),
        state: "registered",
        isHub: false,
      });
    }
  }

  private nextOrder(): number {
    let max = -1;
    for (const e of this.entries.values()) {
      if (!e.isHub) max = Math.max(max, e.order);
    }
    return max + 1;
  }

  get(id: string): RegistryEntry | undefined {
    return this.entries.get(id);
  }

  has(id: string): boolean {
    return this.entries.has(id);
  }

  all(): RegistryEntry[] {
    return [...this.entries.values()];
  }

  getActivePluginId(): string | null {
    return this.config.activePluginId;
  }

  setActivePluginId(id: string | null): void {
    this.config.activePluginId = id;
    this.persist();
  }

  setState(id: string, state: PluginRuntimeState): void {
    const entry = this.entries.get(id);
    if (entry) entry.state = state;
  }

  register(manifest: PluginManifest, dir: string): void {
    this.entries.set(manifest.id, {
      manifest,
      dir,
      enabled: true,
      order: this.nextOrder(),
      state: "registered",
      isHub: false,
    });
    this.persistPluginsList();
    this.emitChanged("installed");
  }

  unregister(id: string): void {
    this.entries.delete(id);
    if (this.config.activePluginId === id) {
      this.config.activePluginId = null;
    }
    this.persistPluginsList();
    this.emitChanged("uninstalled");
  }

  setEnabled(id: string, enabled: boolean): boolean {
    const entry = this.entries.get(id);
    if (!entry || entry.isHub) return false;
    entry.enabled = enabled;
    this.persistPluginsList();
    this.emitChanged("enabled-changed");
    return true;
  }

  reorder(orderedIds: string[]): boolean {
    // Hub is never part of the reorderable list — ignore it if present.
    const nonHubIds = orderedIds.filter((id) => id !== HUB_PLUGIN_ID);
    nonHubIds.forEach((id, index) => {
      const entry = this.entries.get(id);
      if (entry && !entry.isHub) entry.order = index;
    });
    this.persistPluginsList();
    this.emitChanged("reordered");
    return true;
  }

  private persistPluginsList(): void {
    this.config.plugins = this.all()
      .filter((e) => !e.isHub)
      .map((e) => ({ id: e.manifest.id, enabled: e.enabled, order: e.order }));
    this.persist();
  }

  private persist(): void {
    saveConfig(this.config);
  }

  getConfig(): ShellConfig {
    return this.config;
  }

  snapshot(): RegistrySnapshot {
    const plugins: PluginSnapshotEntry[] = this.all()
      .sort((a, b) => (a.isHub ? 1 : b.isHub ? -1 : a.order - b.order))
      .map((e) => ({
        manifest: e.manifest,
        enabled: e.enabled,
        order: e.order,
        state: e.state,
        isHub: e.isHub,
      }));
    return { activePluginId: this.config.activePluginId, plugins };
  }

  private emitChanged(reason: PluginsChangedReason): void {
    this.emit("changed", reason, this.snapshot());
  }

  /** Called by lifecycle.ts on crash — a crash never deregisters a
   * plugin (Technical Specification §14). */
  markCrashed(id: string): void {
    this.setState(id, "crashed");
  }
}
