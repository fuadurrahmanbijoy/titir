import { WebContentsView, type BrowserWindow } from "electron";
import * as path from "path";
import type { PluginManifest } from "../shared/types";

/**
 * One WebContentsView per mounted plugin, attached via
 * win.contentView.addChildView(view) — not an <iframe>, not a
 * <webview> tag (Technical Specification §4). Each plugin view gets
 * its own dedicated preload script, loaded fresh at mount time. This
 * includes the built-in Hub — it is a real mounted view like any other
 * plugin.
 *
 * View security defaults, no exceptions (Technical Specification §4):
 * contextIsolation: true, sandbox: true, nodeIntegration: false.
 */
export function createPluginView(
  win: BrowserWindow,
  manifest: PluginManifest,
  pluginDir: string
): WebContentsView {
  const view = new WebContentsView({
    webPreferences: {
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      preload: path.join(pluginDir, manifest.preload),
    },
  });

  win.contentView.addChildView(view);
  // Start zeroed — lifecycle.ts is responsible for setting real bounds
  // the moment the plugin becomes visible (Technical Specification §8, §10).
  view.setBounds({ x: 0, y: 0, width: 0, height: 0 });

  const entryPath = path.join(pluginDir, manifest.entry);
  view.webContents.loadFile(entryPath);

  return view;
}

export function destroyPluginView(win: BrowserWindow, view: WebContentsView): void {
  try {
    win.contentView.removeChildView(view);
  } catch {
    // view may already be detached (e.g. after a crash) — safe to ignore
  }
  // WebContentsView's underlying WebContents is closed by Electron
  // when detached and garbage collected; nothing else to clean up here.
}
