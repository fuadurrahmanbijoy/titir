import type { BrowserWindow, WebContentsView } from "electron";
import { NAV_WIDTH } from "../shared/constants";
import { createPluginView, destroyPluginView } from "./plugin-loader";
import type { PluginRegistry } from "./plugin-registry";

/**
 * State machine (Technical Specification §8):
 *
 *  registered --(icon clicked)--> mounted --> visible <-> hidden
 *      |                              |
 *      |                              +--(render-process-gone)--> crashed --(relaunch)--> mounted
 *      |
 *      +--(uninstall)--> unregistered
 *
 * A plugin is never mounted before its icon is first clicked. A
 * mounted plugin is never destroyed except on crash or explicit
 * uninstall — it keeps running in the background while hidden.
 */
export class PluginLifecycle {
  private views = new Map<string, WebContentsView>();

  constructor(
    private win: BrowserWindow,
    private registry: PluginRegistry,
    private onCrashed: (pluginId: string) => void
  ) {}

  private contentBounds(): { x: number; y: number; width: number; height: number } {
    const [winW, winH] = this.win.getContentSize();
    return { x: NAV_WIDTH, y: 0, width: Math.max(0, winW - NAV_WIDTH), height: winH };
  }

  /** Mounts (if needed) and shows the given plugin, hiding whatever was
   * previously visible. Creation is lazy — only ever on first click. */
  show(pluginId: string): void {
    const previous = this.registry.getActivePluginId();
    if (previous && previous !== pluginId) {
      this.hide(previous);
    }

    let view = this.views.get(pluginId);
    if (!view) {
      const entry = this.registry.get(pluginId);
      if (!entry) return;
      view = createPluginView(this.win, entry.manifest, entry.dir);
      this.views.set(pluginId, view);
      view.webContents.on("render-process-gone", () => {
        this.handleCrash(pluginId);
      });
    }

    view.setBounds(this.contentBounds());
    this.registry.setState(pluginId, "visible");
    this.registry.setActivePluginId(pluginId);
  }

  /** Zeroes bounds but keeps the process running in the background
   * (Technical Specification §8, §10). */
  hide(pluginId: string): void {
    const view = this.views.get(pluginId);
    if (!view) return;
    view.setBounds({ x: 0, y: 0, width: 0, height: 0 });
    this.registry.setState(pluginId, "hidden");
  }

  /** Re-applies the currently-visible plugin's bounds on window resize
   * (Technical Specification §10). NAV_WIDTH never changes with window
   * size — it's a fixed constant, not a proportion. */
  onWindowResize(): void {
    const activeId = this.registry.getActivePluginId();
    if (!activeId) return;
    const view = this.views.get(activeId);
    if (!view) return;
    view.setBounds(this.contentBounds());
  }

  /** Tears down exactly one plugin's view (uninstall path). Every
   * other plugin, mounted or not, is completely unaffected. */
  unmount(pluginId: string): void {
    const view = this.views.get(pluginId);
    if (!view) return;
    destroyPluginView(this.win, view);
    this.views.delete(pluginId);
    if (this.registry.getActivePluginId() === pluginId) {
      this.registry.setActivePluginId(null);
    }
  }

  /** render-process-gone: the view is torn down immediately, but the
   * registry entry is kept exactly as it was — a crash never
   * deregisters a plugin (Technical Specification §14). No in-memory
   * plugin state is ever assumed to survive. */
  private handleCrash(pluginId: string): void {
    const view = this.views.get(pluginId);
    if (view) {
      destroyPluginView(this.win, view);
      this.views.delete(pluginId);
    }
    this.registry.markCrashed(pluginId);
    if (this.registry.getActivePluginId() === pluginId) {
      this.registry.setActivePluginId(null);
    }
    this.onCrashed(pluginId);
  }

  /** Clicking "Relaunch" re-triggers mount for that specific pluginId
   * only — every other plugin, mounted or not, is completely
   * unaffected (Technical Specification §14). */
  relaunch(pluginId: string): void {
    this.show(pluginId);
  }
}
