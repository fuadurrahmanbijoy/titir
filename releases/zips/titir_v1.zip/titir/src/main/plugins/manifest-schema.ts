import { z } from "zod";
import { RESERVED_ID_PREFIX, HUB_PLUGIN_ID } from "../shared/constants";
import type { PluginManifest } from "../shared/types";

// Lowercase, alphanumeric plus '.'/'-' (Technical Specification §6).
const ID_PATTERN = /^[a-z0-9.-]+$/;

const manifestSchema = z.object({
  id: z.string().min(1).regex(ID_PATTERN, {
    message: "id must be lowercase alphanumeric plus '.' or '-'",
  }),
  name: z.string().min(1),
  version: z.string().min(1),
  entry: z.string().min(1),
  preload: z.string().min(1),
  icon: z.string().optional(),
  summary: z.string().optional(),
  permissions: z.array(z.string()).optional(),
  minShellVersion: z.string().optional(),
});

export interface ManifestValidationResult {
  ok: boolean;
  manifest?: PluginManifest;
  errors: string[];
}

/**
 * Validates a raw parsed JSON value against the manifest schema
 * (Technical Specification §6) and applies the two structural rules
 * that a plain zod shape can't express:
 *   - the `titir.*` id namespace is reserved for built-in plugins
 *   - (uniqueness against already-installed ids is checked by the
 *     caller, which has the registry — see plugin-installer.ts)
 */
export function validateManifest(
  raw: unknown,
  opts: { allowReservedNamespace?: boolean } = {}
): ManifestValidationResult {
  const parsed = manifestSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      errors: parsed.error.issues.map(
        (issue) => `${issue.path.join(".") || "(root)"}: ${issue.message}`
      ),
    };
  }

  const manifest = parsed.data as PluginManifest;
  const errors: string[] = [];

  const isReserved = manifest.id.startsWith(RESERVED_ID_PREFIX);
  const allowReserved = opts.allowReservedNamespace ?? false;
  if (isReserved && !(allowReserved && manifest.id === HUB_PLUGIN_ID)) {
    errors.push(
      `id "${manifest.id}" uses the reserved "${RESERVED_ID_PREFIX}*" namespace, which is limited to built-in plugins`
    );
  }

  // The manifest can never point at a .ts/.tsx file (§6, §16) — TiTir
  // never compiles installed plugin code.
  for (const [field, value] of [
    ["entry", manifest.entry],
    ["preload", manifest.preload],
  ] as const) {
    if (/\.tsx?$/i.test(value)) {
      errors.push(`${field} must point at compiled JS/HTML, not a .ts/.tsx source file: "${value}"`);
    }
  }

  if (errors.length > 0) {
    return { ok: false, errors };
  }
  return { ok: true, manifest, errors: [] };
}
