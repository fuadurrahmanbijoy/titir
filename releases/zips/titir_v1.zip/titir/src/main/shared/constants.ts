// Single source of truth for layout constants shared by main-process
// bounds math (lifecycle.ts) and the shell renderer's own CSS
// (styles.css generates --titir-nav-width / --titir-titlebar-height
// from these at boot — see Technical Specification §10, Visual Guide
// §A1). Never hardcode these numbers a second time anywhere.

export const NAV_WIDTH = 72;
export const TITLEBAR_HEIGHT = 40;

export const RESERVED_ID_PREFIX = "titir.";
export const HUB_PLUGIN_ID = "titir.hub";

export const CONFIG_FILE_NAME = "titir.config.json";
export const INSTALLED_PLUGINS_DIR = "installed";
export const BUILTIN_PLUGINS_DIR = "builtin";
