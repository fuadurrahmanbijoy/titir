// Shared type defs (Manifest, ShellConfig, IpcChannelMap). Imported by
// main, preload, and renderer alike — see Technical Specification §5,
// §6, §9, §11.

export interface PluginManifest {
  id: string;
  name: string;
  version: string;
  entry: string;
  preload: string;
  icon?: string;
  summary?: string;
  permissions?: string[];
  minShellVersion?: string;
}

export interface ShellConfig {
  window: { width: number; height: number; x: number | null; y: number | null };
  activePluginId: string | null;
  plugins: Array<{ id: string; enabled: boolean; order: number }>;
}

// Runtime lifecycle state for a single plugin (Technical Spec §8).
// Note: "unregistered" is a transition, not a state ever present in a
// snapshot — an unregistered plugin simply isn't in the registry.
export type PluginRuntimeState =
  | "registered"
  | "mounted"
  | "visible"
  | "hidden"
  | "crashed";

export interface PluginSnapshotEntry {
  manifest: PluginManifest;
  enabled: boolean;
  order: number;
  state: PluginRuntimeState;
  isHub: boolean;
}

export interface RegistrySnapshot {
  activePluginId: string | null;
  plugins: PluginSnapshotEntry[];
}

export type PluginsChangedReason =
  | "installed"
  | "uninstalled"
  | "enabled-changed"
  | "reordered";

// ---- IPC payload/response shapes (Technical Specification §11) ----

export interface InstallPluginRequest {
  packagePath: string;
}
export interface InstallPluginResponse {
  ok: boolean;
  pluginId?: string;
  error?: string;
}

export interface UninstallPluginRequest {
  pluginId: string;
}
export interface UninstallPluginResponse {
  ok: boolean;
  error?: string;
}

export interface SetPluginEnabledRequest {
  pluginId: string;
  enabled: boolean;
}
export interface SetPluginEnabledResponse {
  ok: boolean;
}

export interface ReorderPluginsRequest {
  orderedIds: string[];
}
export interface ReorderPluginsResponse {
  ok: boolean;
}

export interface OpenFileRequest {
  properties: string[];
  filters?: { name: string; extensions: string[] }[];
}
export interface OpenFileResponse {
  canceled: boolean;
  filePaths: string[];
}

// Not present in Technical Specification §11's channel table, but
// required by the state machine in §8 ("clicking an icon mounts and
// shows that plugin") and the crash-toast Relaunch action (§14, Visual
// Guide §A6) — the shell renderer has no other way to drive these
// transitions. Wired into the shell preload only (shell-preload.ts),
// the same "shell renderer only" tier as window:*.
export interface ShowPluginRequest {
  pluginId: string;
}
export interface RelaunchPluginRequest {
  pluginId: string;
}

export interface PluginCrashedEvent {
  pluginId: string;
}

export interface PluginsChangedEvent {
  reason: PluginsChangedReason;
  snapshot: RegistrySnapshot;
}

// Central map of every channel that crosses the main/renderer boundary
// (Technical Specification §11) — preload and handler code share this
// one type instead of drifting apart independently.
export interface IpcChannelMap {
  "titir:installPlugin": (req: InstallPluginRequest) => InstallPluginResponse;
  "titir:uninstallPlugin": (req: UninstallPluginRequest) => UninstallPluginResponse;
  "titir:setPluginEnabled": (req: SetPluginEnabledRequest) => SetPluginEnabledResponse;
  "titir:reorderPlugins": (req: ReorderPluginsRequest) => ReorderPluginsResponse;
  "titir:getSnapshot": (req: Record<string, never>) => RegistrySnapshot;
  "dialog:openFile": (req: OpenFileRequest) => OpenFileResponse;
  "window:minimize": (req: Record<string, never>) => void;
  "window:maximize": (req: Record<string, never>) => void;
  "window:close": (req: Record<string, never>) => void;
  "titir:showPlugin": (req: ShowPluginRequest) => void;
  "titir:relaunchPlugin": (req: RelaunchPluginRequest) => void;
}
