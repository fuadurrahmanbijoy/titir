import React, { Component, useEffect, useState, type CSSProperties } from "react";
import { NAV_WIDTH, TITLEBAR_HEIGHT } from "../main/shared/constants";
import type { PluginCrashedEvent, RegistrySnapshot } from "../main/shared/types";
import { NavColumn } from "./nav/NavColumn";
import type { ShellWindowApi } from "./shell-window-api";

// Ambient contextBridge surface exposed by shell-preload.ts. See
// shell-window-api.ts for the shared shape.
declare global {
  interface Window {
    titir: ShellWindowApi["titir"];
    windowApi: ShellWindowApi["windowApi"];
    dialogApi: ShellWindowApi["dialogApi"];
  }
}

/**
 * A top-level React error boundary (Technical Specification §12). The
 * shell renderer is the one renderer a person can never "relaunch" the
 * way a crashed plugin can (§14) — if it throws during render, there
 * is no chrome left to show a relaunch button in. The fallback here is
 * plain DOM, no React required to render it, so a bug in one part of
 * the navigation column cannot take the entire shell down to a blank
 * window.
 */
class ShellErrorBoundary extends Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): { hasError: boolean } {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    // eslint-disable-next-line no-console
    console.error("TiTir shell renderer crashed:", error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="titir-fallback-error">
          <p>Something went wrong in the TiTir shell.</p>
          <button onClick={() => this.setState({ hasError: false })}>Retry</button>
        </div>
      );
    }
    return this.props.children;
  }
}

function IdleState() {
  return (
    <div className="titir-idle-state">
      <svg
        className="titir-idle-mascot"
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        {/* PuFi's mark: monochrome, currentColor, quiet — appears only
            here in shell chrome (Visual Guide §A5). */}
        <circle cx="24" cy="20" r="12" stroke="currentColor" strokeWidth="2" />
        <circle cx="19" cy="18" r="1.6" fill="currentColor" />
        <circle cx="29" cy="18" r="1.6" fill="currentColor" />
        <path d="M18 26c2 2 10 2 12 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path d="M14 12c-2-3-1-7 2-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path d="M34 12c2-3 1-7-2-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
      <p className="titir-idle-wordmark">TiTir</p>
      <p className="titir-idle-tagline">Select a plugin to get started</p>
    </div>
  );
}

function CrashToast({
  pluginName,
  onRelaunch,
  onDismiss,
}: {
  pluginName: string;
  onRelaunch: () => void;
  onDismiss: () => void;
}) {
  useEffect(() => {
    const timer = setTimeout(onDismiss, 8000);
    return () => clearTimeout(timer);
  }, [onDismiss]);

  return (
    <div className="titir-crash-toast" role="alert">
      <p className="titir-crash-toast-message">{pluginName} crashed</p>
      <button className="titir-crash-toast-relaunch" onClick={onRelaunch}>
        Relaunch
      </button>
    </div>
  );
}

function ShellApp() {
  const [snapshot, setSnapshot] = useState<RegistrySnapshot | null>(null);
  const [crashed, setCrashed] = useState<PluginCrashedEvent | null>(null);

  useEffect(() => {
    // titir:getSnapshot is a one-shot bootstrap call for populating
    // initial state right after the renderer first mounts, before any
    // change event has had a chance to arrive (Technical Spec §8) —
    // never called again after this.
    window.titir.getSnapshot().then(setSnapshot);

    const unsubscribeChanged = window.titir.onPluginsChanged((event) => {
      setSnapshot(event.snapshot);
    });
    const unsubscribeCrashed = window.titir.onPluginCrashed((event) => {
      setCrashed(event);
    });

    return () => {
      unsubscribeChanged();
      unsubscribeCrashed();
    };
  }, []);

  const activePluginId = snapshot?.activePluginId ?? null;
  const showIdleState = !activePluginId;

  const crashedPlugin = crashed
    ? snapshot?.plugins.find((p) => p.manifest.id === crashed.pluginId)
    : undefined;

  // Single source of truth: NAV_WIDTH / TITLEBAR_HEIGHT come from
  // src/main/shared/constants.ts, imported here directly, so the
  // literal 72/40 can never drift between main-process bounds math
  // and the renderer's own CSS (Technical Specification §10, Visual
  // Guide §A1). CSS custom properties aren't part of CSSProperties'
  // typed keys, hence the cast.
  const rootStyle = {
    "--titir-nav-width": `${NAV_WIDTH}px`,
    "--titir-titlebar-height": `${TITLEBAR_HEIGHT}px`,
  } as CSSProperties;

  return (
    <div className="titir-app" style={rootStyle}>
      <NavColumn snapshot={snapshot} activePluginId={activePluginId} />
      {showIdleState && <IdleState />}
      {crashed && crashedPlugin && (
        <CrashToast
          pluginName={crashedPlugin.manifest.name}
          onRelaunch={() => {
            window.titir.relaunchPlugin({ pluginId: crashed.pluginId });
            setCrashed(null);
          }}
          onDismiss={() => setCrashed(null)}
        />
      )}
    </div>
  );
}

export function App() {
  return (
    <ShellErrorBoundary>
      <ShellApp />
    </ShellErrorBoundary>
  );
}
