import React, { useState } from "react";
import type { PluginSnapshotEntry } from "../../main/shared/types";

/**
 * Exactly one icon, for the built-in Hub. Never part of the
 * scrollable list above it, never reorderable, never removable
 * (Technical Specification §10). Draws from the same nav-icon
 * states/sizing as any other plugin (Visual Guide §A2) — the Hub is a
 * real mounted plugin, not a special avatar widget.
 */
export function HubEntry({
  hub,
  activePluginId,
}: {
  hub: PluginSnapshotEntry;
  activePluginId: string | null;
}) {
  const [hovered, setHovered] = useState(false);
  const isActive = hub.manifest.id === activePluginId;
  const isCrashed = hub.state === "crashed";

  const classes = [
    "titir-nav-icon",
    isActive ? "active" : "",
    isCrashed ? "crashed" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className="titir-hub-slot">
      <button
        className={classes}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={() => {
          if (isCrashed) {
            window.titir.relaunchPlugin({ pluginId: hub.manifest.id });
          } else {
            window.titir.showPlugin({ pluginId: hub.manifest.id });
          }
        }}
        aria-label={hub.manifest.name}
      >
        <span aria-hidden="true">{hub.manifest.icon ?? "▢"}</span>
        {hovered && (
          <span className="titir-nav-tooltip">
            {isCrashed ? "Crashed — click to relaunch" : hub.manifest.name}
          </span>
        )}
      </button>
    </div>
  );
}
