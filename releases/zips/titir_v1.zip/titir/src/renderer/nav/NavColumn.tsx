import React from "react";
import type { RegistrySnapshot } from "../../main/shared/types";
import { WindowControlsRow } from "./WindowControlsRow";
import { PluginList } from "./PluginList";
import { HubEntry } from "./HubEntry";

/**
 * Composes the three stacked regions described in Technical
 * Specification §10 / Visual Guide §A2: window controls row (top,
 * fixed), plugin list (middle, scrollable), Hub slot (bottom, fixed
 * — never part of the scrollable list above it).
 */
export function NavColumn({
  snapshot,
  activePluginId,
}: {
  snapshot: RegistrySnapshot | null;
  activePluginId: string | null;
}) {
  const nonHubPlugins = (snapshot?.plugins ?? [])
    .filter((p) => !p.isHub && p.enabled)
    .sort((a, b) => a.order - b.order);

  const hub = snapshot?.plugins.find((p) => p.isHub);

  return (
    <nav className="titir-nav-column">
      <WindowControlsRow />
      <PluginList plugins={nonHubPlugins} activePluginId={activePluginId} />
      {hub && <HubEntry hub={hub} activePluginId={activePluginId} />}
    </nav>
  );
}
