import React from "react";

/**
 * Houses the three custom window-control buttons and doubles as the
 * window's drag handle (Technical Specification §13, Visual Guide
 * §A2). The row's own background carries -webkit-app-region: drag
 * (styles.css); the three buttons are individually no-drag so a click
 * registers instead of starting a window move. No IPC channel is
 * involved in the drag itself — it's native OS-level window movement.
 */
export function WindowControlsRow() {
  return (
    <div className="titir-window-controls">
      <button
        className="minimize"
        aria-label="Minimize"
        onClick={() => window.windowApi.minimize()}
      />
      <button
        className="maximize"
        aria-label="Maximize"
        onClick={() => window.windowApi.maximize()}
      />
      <button
        className="close"
        aria-label="Close"
        onClick={() => window.windowApi.close()}
      />
    </div>
  );
}
