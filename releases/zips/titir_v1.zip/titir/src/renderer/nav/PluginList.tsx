import React, { useState } from "react";
import type { PluginSnapshotEntry } from "../../main/shared/types";

/**
 * Vertically scrollable, drag-reorderable list of icons, one per
 * enabled, installed plugin, in plugins[].order order (Technical
 * Specification §10). Clicking an icon mounts (if not already
 * mounted) and shows that plugin.
 *
 * Renders purely from the `plugins` prop, which App.tsx derives from
 * its single titir:pluginsChanged subscription — this satisfies
 * Technical Specification §8's "push-based, never poll-based" rule
 * without a second, redundant subscription in this component.
 */
export function PluginList({
  plugins,
  activePluginId,
}: {
  plugins: PluginSnapshotEntry[];
  activePluginId: string | null;
}) {
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  function handleDrop(targetId: string) {
    if (!draggingId || draggingId === targetId) {
      setDraggingId(null);
      return;
    }
    const ids = plugins.map((p) => p.manifest.id);
    const fromIndex = ids.indexOf(draggingId);
    const toIndex = ids.indexOf(targetId);
    if (fromIndex === -1 || toIndex === -1) {
      setDraggingId(null);
      return;
    }
    const reordered = [...ids];
    reordered.splice(fromIndex, 1);
    reordered.splice(toIndex, 0, draggingId);
    window.titir.reorderPlugins({ orderedIds: reordered });
    setDraggingId(null);
  }

  return (
    <div className="titir-plugin-list">
      {plugins.map((p) => {
        const isActive = p.manifest.id === activePluginId;
        const isCrashed = p.state === "crashed";
        const classes = [
          "titir-nav-icon",
          isActive ? "active" : "",
          isCrashed ? "crashed" : "",
          draggingId === p.manifest.id ? "dragging" : "",
        ]
          .filter(Boolean)
          .join(" ");

        return (
          <button
            key={p.manifest.id}
            className={classes}
            draggable
            onDragStart={() => setDraggingId(p.manifest.id)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => handleDrop(p.manifest.id)}
            onDragEnd={() => setDraggingId(null)}
            onMouseEnter={() => setHoveredId(p.manifest.id)}
            onMouseLeave={() => setHoveredId(null)}
            onClick={() => {
              if (isCrashed) {
                window.titir.relaunchPlugin({ pluginId: p.manifest.id });
              } else {
                window.titir.showPlugin({ pluginId: p.manifest.id });
              }
            }}
            aria-label={p.manifest.name}
          >
            <span aria-hidden="true">{p.manifest.icon ?? "▢"}</span>
            {hoveredId === p.manifest.id && (
              <span className="titir-nav-tooltip">
                {isCrashed ? "Crashed — click to relaunch" : p.manifest.name}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
