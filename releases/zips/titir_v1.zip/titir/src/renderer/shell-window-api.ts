import type {
  InstallPluginRequest,
  InstallPluginResponse,
  UninstallPluginRequest,
  UninstallPluginResponse,
  SetPluginEnabledRequest,
  SetPluginEnabledResponse,
  ReorderPluginsRequest,
  ReorderPluginsResponse,
  RegistrySnapshot,
  OpenFileRequest,
  OpenFileResponse,
  PluginCrashedEvent,
  PluginsChangedEvent,
  ShowPluginRequest,
  RelaunchPluginRequest,
} from "../main/shared/types";

// Mirrors the exact surface exposed by contextBridge in
// src/main/preload/shell-preload.ts. Kept as a type-only import so the
// renderer never pulls in Electron's own runtime.
export interface ShellWindowApi {
  titir: {
    installPlugin: (req: InstallPluginRequest) => Promise<InstallPluginResponse>;
    uninstallPlugin: (req: UninstallPluginRequest) => Promise<UninstallPluginResponse>;
    setPluginEnabled: (req: SetPluginEnabledRequest) => Promise<SetPluginEnabledResponse>;
    reorderPlugins: (req: ReorderPluginsRequest) => Promise<ReorderPluginsResponse>;
    getSnapshot: () => Promise<RegistrySnapshot>;
    showPlugin: (req: ShowPluginRequest) => Promise<void>;
    relaunchPlugin: (req: RelaunchPluginRequest) => Promise<void>;
    onPluginsChanged: (listener: (event: PluginsChangedEvent) => void) => () => void;
    onPluginCrashed: (listener: (event: PluginCrashedEvent) => void) => () => void;
  };
  dialogApi: {
    openFile: (req: OpenFileRequest) => Promise<OpenFileResponse>;
  };
  windowApi: {
    minimize: () => Promise<void>;
    maximize: () => Promise<void>;
    close: () => Promise<void>;
  };
}
