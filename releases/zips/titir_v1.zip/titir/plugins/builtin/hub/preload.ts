import { contextBridge, ipcRenderer } from "electron";

// The Hub's own preload. This is the one plugin preload that wires the
// titir:* management channels in — "by convention," per Technical
// Specification §11/§16, since v1 has no enforced technical permission
// system. A third-party plugin's own preload never receives this
// contextBridge surface unless its author chose to wire the raw
// ipcRenderer calls in themselves, which is explicitly out of scope
// for this document to police (§16).

interface PluginManifest {
  id: string;
  name: string;
  version: string;
  entry: string;
  preload: string;
  icon?: string;
  summary?: string;
  permissions?: string[];
  minShellVersion?: string;
}

interface PluginSnapshotEntry {
  manifest: PluginManifest;
  enabled: boolean;
  order: number;
  state: string;
  isHub: boolean;
}

interface RegistrySnapshot {
  activePluginId: string | null;
  plugins: PluginSnapshotEntry[];
}

interface PluginsChangedEvent {
  reason: "installed" | "uninstalled" | "enabled-changed" | "reordered";
  snapshot: RegistrySnapshot;
}

const hubApi = {
  installPlugin: (packagePath: string) =>
    ipcRenderer.invoke("titir:installPlugin", { packagePath }),
  uninstallPlugin: (pluginId: string) =>
    ipcRenderer.invoke("titir:uninstallPlugin", { pluginId }),
  setPluginEnabled: (pluginId: string, enabled: boolean) =>
    ipcRenderer.invoke("titir:setPluginEnabled", { pluginId, enabled }),
  reorderPlugins: (orderedIds: string[]) =>
    ipcRenderer.invoke("titir:reorderPlugins", { orderedIds }),
  getSnapshot: (): Promise<RegistrySnapshot> =>
    ipcRenderer.invoke("titir:getSnapshot", {}),
  onPluginsChanged: (listener: (event: PluginsChangedEvent) => void) => {
    const handler = (_e: unknown, payload: PluginsChangedEvent) => listener(payload);
    ipcRenderer.on("titir:pluginsChanged", handler);
    return () => ipcRenderer.removeListener("titir:pluginsChanged", handler);
  },
  // dialog:openFile — the one utility every plugin's preload may call
  // (Technical Specification §11, §15), used here to pick a .titirpkg
  // file to install.
  openFile: (filters?: { name: string; extensions: string[] }[]) =>
    ipcRenderer.invoke("dialog:openFile", { properties: ["openFile"], filters }),
};

contextBridge.exposeInMainWorld("hub", hubApi);

export type HubApi = typeof hubApi;
