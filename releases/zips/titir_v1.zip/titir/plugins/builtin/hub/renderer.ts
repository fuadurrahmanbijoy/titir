// Hub's own renderer. Plain DOM manipulation TypeScript, compiled down
// to a classic (non-module) script before packaging — Technical
// Specification §16: TiTir never runs a compiler on installed plugin
// code, and a plugin author's own toolchain choice (framework or none)
// is entirely their own business, including the Hub's.

interface PluginManifest {
  id: string;
  name: string;
  version: string;
  entry: string;
  preload: string;
  icon?: string;
  summary?: string;
  permissions?: string[];
  minShellVersion?: string;
}

interface PluginSnapshotEntry {
  manifest: PluginManifest;
  enabled: boolean;
  order: number;
  state: string;
  isHub: boolean;
}

interface RegistrySnapshot {
  activePluginId: string | null;
  plugins: PluginSnapshotEntry[];
}

interface HubApi {
  installPlugin: (packagePath: string) => Promise<{ ok: boolean; pluginId?: string; error?: string }>;
  uninstallPlugin: (pluginId: string) => Promise<{ ok: boolean; error?: string }>;
  setPluginEnabled: (pluginId: string, enabled: boolean) => Promise<{ ok: boolean }>;
  reorderPlugins: (orderedIds: string[]) => Promise<{ ok: boolean }>;
  getSnapshot: () => Promise<RegistrySnapshot>;
  onPluginsChanged: (listener: (event: { reason: string; snapshot: RegistrySnapshot }) => void) => () => void;
  openFile: (
    filters?: { name: string; extensions: string[] }[]
  ) => Promise<{ canceled: boolean; filePaths: string[] }>;
}

interface Window {
  hub: HubApi;
}

(function main() {
  const root = document.getElementById("hub-root");
  if (!root) return;

  root.innerHTML = [
    '<div class="hub">',
    "<h1>Hub</h1>",
    '<p class="hub-subtitle">Install, enable, disable, and remove plugins.</p>',
    '<div class="hub-dropzone" id="hub-dropzone">',
    "Drag a .titirpkg file here, or",
    '<div><button id="hub-pick-file">Choose a file&hellip;</button></div>',
    '<div class="hub-error" id="hub-error" style="display:none;"></div>',
    "</div>",
    '<div class="hub-plugin-list" id="hub-plugin-list"></div>',
    "</div>",
  ].join("");

  const listEl = document.getElementById("hub-plugin-list")!;
  const errorEl = document.getElementById("hub-error")!;
  const dropzoneEl = document.getElementById("hub-dropzone")!;
  const pickFileBtn = document.getElementById("hub-pick-file")!;

  function showError(message: string) {
    errorEl.textContent = message;
    errorEl.style.display = "block";
  }

  function clearError() {
    errorEl.style.display = "none";
    errorEl.textContent = "";
  }

  function render(snapshot: RegistrySnapshot) {
    const installed = snapshot.plugins
      .filter((p) => !p.isHub)
      .sort((a, b) => a.order - b.order);

    if (installed.length === 0) {
      listEl.innerHTML = '<p class="hub-empty">No plugins installed yet.</p>';
      return;
    }

    listEl.innerHTML = installed
      .map((p) => {
        const permissions = p.manifest.permissions?.length
          ? `Permissions (informational only): ${p.manifest.permissions.join(", ")}`
          : "No declared permissions.";
        return [
          `<div class="hub-plugin-row" data-plugin-id="${p.manifest.id}">`,
          `<div class="hub-plugin-icon">${p.manifest.icon ?? "▢"}</div>`,
          '<div class="hub-plugin-info">',
          `<p class="hub-plugin-name">${p.manifest.name}</p>`,
          `<p class="hub-plugin-meta">v${p.manifest.version}${p.manifest.summary ? " — " + p.manifest.summary : ""}</p>`,
          `<p class="hub-plugin-permissions">${permissions}</p>`,
          "</div>",
          '<div class="hub-plugin-actions">',
          `<button class="hub-toggle ${p.enabled ? "on" : ""}" data-action="toggle" data-plugin-id="${p.manifest.id}" data-enabled="${p.enabled}" aria-label="Enable or disable"></button>`,
          `<button class="hub-uninstall" data-action="uninstall" data-plugin-id="${p.manifest.id}">Uninstall</button>`,
          "</div>",
          "</div>",
        ].join("");
      })
      .join("");
  }

  listEl.addEventListener("click", (event) => {
    const target = event.target as HTMLElement;
    const action = target.getAttribute("data-action");
    const pluginId = target.getAttribute("data-plugin-id");
    if (!action || !pluginId) return;

    if (action === "toggle") {
      const currentlyEnabled = target.getAttribute("data-enabled") === "true";
      window.hub.setPluginEnabled(pluginId, !currentlyEnabled);
    } else if (action === "uninstall") {
      window.hub.uninstallPlugin(pluginId).then((result) => {
        if (!result.ok && result.error) showError(result.error);
      });
    }
  });

  async function installFromPath(path: string) {
    clearError();
    const result = await window.hub.installPlugin(path);
    if (!result.ok && result.error) {
      showError(result.error);
    }
  }

  pickFileBtn.addEventListener("click", async () => {
    const result = await window.hub.openFile([{ name: "TiTir Plugin", extensions: ["titirpkg"] }]);
    if (!result.canceled && result.filePaths[0]) {
      installFromPath(result.filePaths[0]);
    }
  });

  dropzoneEl.addEventListener("dragover", (event) => {
    event.preventDefault();
    dropzoneEl.classList.add("drag-over");
  });
  dropzoneEl.addEventListener("dragleave", () => {
    dropzoneEl.classList.remove("drag-over");
  });
  dropzoneEl.addEventListener("drop", (event) => {
    event.preventDefault();
    dropzoneEl.classList.remove("drag-over");
    const file = event.dataTransfer?.files?.[0] as (File & { path?: string }) | undefined;
    if (file && file.path) {
      installFromPath(file.path);
    } else {
      showError("Could not read the dropped file's path.");
    }
  });

  window.hub.getSnapshot().then(render);
  window.hub.onPluginsChanged((event) => render(event.snapshot));
})();
