# TiTir

> TiTir is a collection of apps, not one app.

A thin desktop host for independently-built, isolated plugins.
Mascot: **PuFi**.

TiTir itself does almost nothing beyond loading, isolating, and
switching between plugins — small, self-contained programs installed
at runtime by handing TiTir a `.titirpkg` package file. No plugin can
corrupt, freeze, or read another plugin's state, or the shell's own.

## Documentation

1. **`titir_technical_specification.md`** (project root, not shipped
   in `docs/` since it describes the shell itself) — the complete
   build specification: process model, package format, IPC contract,
   state machine, security hardening. Start here.
2. **`docs/plugin-guide.md`** — the plugin-author-facing subset of the
   spec, if you're building *a* plugin rather than modifying the shell.
3. **`docs/visual-guide.md`** — shared design tokens. MANDATORY if
   you're touching shell chrome (the 72px nav column); a recommended,
   non-enforced default if you're styling a plugin's own interior.

## Getting Started

```bash
pnpm install
pnpm run build      # tsc for main/preload, Vite for the shell renderer,
                     # tsc for the built-in Hub's preload + renderer
pnpm start           # build, then launch electron .
```

Before every release:

```bash
pnpm run audit:deps  # reports outdated deps + high/critical vulnerabilities
```

## Project Layout

```
titir/
├── docs/                     plugin-guide.md, visual-guide.md
├── src/
│   ├── main/                 main process (plain TypeScript, tsc-only)
│   └── renderer/              shell renderer (React, Vite-bundled)
└── plugins/
    ├── builtin/hub/           the one built-in plugin, ships with TiTir
    └── installed/             every runtime-installed plugin lands here
```

See `titir_technical_specification.md` §5 for the full annotated tree.

## Scope (v1)

In scope: the host shell, runtime plugin installation, crash isolation
per plugin, and the Hub (the one built-in plugin for managing others).

Explicitly out of scope: a plugin marketplace or auto-update,
technically-enforced permissions between plugins, any shared UI kit
imposed on plugin authors, multi-window support.

---

*PuFi approves, in the manner of a mascot who has never once read a
technical document.*
